<div id="content">
    <p>Không tồn tại trang này! <br>Quay lại trang chủ <a href="?page=home">Trang chủ</a></p>
</div>
<!--End content-->