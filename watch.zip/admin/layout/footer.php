<div id="footer-wp">
    <div class="wp-inner">
        <p id="copyright">2019 © Nguyễn Ngọc Tường Vi - 05CNTT2</p>
    </div>
</div>
</div>
</div>
</body>
</html>